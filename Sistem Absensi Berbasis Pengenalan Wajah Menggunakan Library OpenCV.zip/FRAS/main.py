import os  # mengakses fungsi os
import check_camera # mengakses fungsi cek kamera
import Capture_Image # mengakses fungsi ambil gambar
import Train_Image # mengakses fungsi latih gambar
import Recognize # mengakses fungsi mengenali objek



# Membuat fungsi title bar
def title_bar():

    # Judul Program program
    print()
    print()
    print()
    print("\t****************************************************")
    print("\t***** Sistem Absensi Berbasis Pengenalan Wajah *****")
    print("\t****************************************************")


# Membuat fungsi main menu
def mainMenu():
    os.system('clear')
    title_bar()
    print()
    print(5 * "*", "MENU UTAMA", 5 * "*")
    print("[1] Cek Kamera")
    print("[2] Menangkap Objek")
    print("[3] Melatih Objek")
    print("[4] Mengenali Objek & Absen")
    print("[5] Keluar")

    while True:
        try:
            choice = int(input("Masukkan Pilihan: "))

            if choice == 1:
                checkCamera()
                break
            elif choice == 2:
                CaptureFaces()
                break
            elif choice == 3:
                Trainimages()
                break
            elif choice == 4:
                RecognizeFaces()
                break
            elif choice == 5:
                print("Terima Kasih")
                break
            else:
                print("Tidak ada pilihan. Masukkan 1-5")
        except ValueError:
            print("Salah Input. Masukkan 1-5\n Coba Lagi")
    exit


# ---------------------------------------------------------
# Memanggil fungsi cek kamera dari file check_camera.py

def checkCamera():
    check_camera.camer()
    key = input("Tekan apapun untuk kembali ke menu utama")
    mainMenu()


# --------------------------------------------------------------
# Memanggil fungsi ambil gambar dari file Capture_image.py

def CaptureFaces():
    Capture_Image.takeImages()
    input("Tekan apapun untuk kembali ke menu utama")
    mainMenu()


# -----------------------------------------------------------------
# Memanggil fungsi Latih objek dari file Train_Image.py

def Trainimages():
    Train_Image.TrainImages()
    input("Tekan apapun untuk kembali ke menu utama")
    mainMenu()


# --------------------------------------------------------------------
# Memanggil fungsi Mengenali objek dan absen dari file Recognize.py

def RecognizeFaces():
    Recognize.recognize_attendence()
    input("Tekan apapun untuk kembali ke menu utama")
    mainMenu()


# ---------------Memanggil Fungsi Utama/ Menu Utama ------------------
mainMenu()
