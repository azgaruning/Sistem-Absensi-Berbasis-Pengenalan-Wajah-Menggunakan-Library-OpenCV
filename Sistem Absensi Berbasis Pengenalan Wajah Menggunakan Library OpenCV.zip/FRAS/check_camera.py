import cv2


def camer():
    cap = cv2.VideoCapture(0)

    while(True):
        #Membaca kamera berfungsi atau tidak
        ret, frame  = cap.read()
        #Operasi mengubah gambar kamera menjadi abu-abu
        gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        #Menampilkan frame kamera
        cv2.imshow('Test', gray)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    #Menutup Frame kamera setelah selesai digunakan
    cap.release()
    cv2.destroyAllWindows()

