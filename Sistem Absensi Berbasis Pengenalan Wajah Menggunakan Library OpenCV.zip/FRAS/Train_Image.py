import os
import cv2
import numpy as np
from PIL import Image


# -------------- Label Gambar ------------------------

def getImagesAndLabels(path):
    # Mendapatkan alamat file di dalam folder 
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]

    # membuat list wajah
    faces = []
    # membuat list ID
    Ids = []
    # Looping pada setiap alamat gambar dan membaca id dan gambar
    for imagePath in imagePaths:
        # Membaca gambar dan merubah ke warna abu-abu
        pilImage = Image.open(imagePath).convert('L')
        # Mengkonversi Gambar PIL ke dalam array numpy
        imageNp = np.array(pilImage, 'uint8')
        # Mendapatkan ID gambar
        Id = int(os.path.split(imagePath)[-1].split(".")[1])
        # Mengekstrak gambar wajah dari sampel gambar
        faces.append(imageNp)
        Ids.append(Id)
    return faces, Ids


# ----------- Fungsi Melatih Objek atau Gambar ---------------
def TrainImages():
    recognizer = cv2.face_LBPHFaceRecognizer.create()
    harcascadePath = "haarcascade_frontalface_default.xml"
    detector = cv2.CascadeClassifier(harcascadePath)
    faces, Id = getImagesAndLabels("TrainingImage")
    recognizer.train(faces, np.array(Id))
    recognizer.save("TrainingImageLabel"+os.sep+"Trainner.yml")
    print("Objek Berhasil Dilatih")
