import csv
import cv2
import os


# Menghitung Angka
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass

    return False



# Fungsi Ambil Gambar
def takeImages():
    Id = input("Masukkan Id: ")
    nama = input("Masukkan Nama: ")

    if(is_number(Id) and nama.isalpha()):
        cam = cv2.VideoCapture(0)
        harcascadePath = "haarcascade_frontalface_default.xml"
        detector = cv2.CascadeClassifier(harcascadePath)
        sampleNum = 0

        while(True):
            ret, img = cam.read()
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = detector.detectMultiScale(gray, 1.3, 5)
            for(x,y,w,h) in faces:
                cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)
                #Autoincrement jumlah sampel
                sampleNum = sampleNum+1
                #menyimpan hasil tangkapan wajah ke dalam dataset folder TrainingImage 
                cv2.imwrite("TrainingImage" + os.sep +nama + "."+Id + '.' +
                            str(sampleNum) + ".jpg", gray[y:y+h, x:x+w])
                #Menampilkan frame kamera
                cv2.imshow('Ambil Gambar', img)
            #Menunggu 100 miliseconds
            if cv2.waitKey(100) & 0xFF == ord('q'):
                break
            # Berhenti jika gambar yang diambil lebih dari 60
            elif sampleNum > 60:
                break
        cam.release()
        cv2.destroyAllWindows()
        row = [Id, nama]
        with open("StudentDetails"+os.sep+"StudentDetails.csv", 'a+') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(row)
        csvFile.close()
    else:
        if(is_number(Id)):
            print("Masukkan Huruf Alfabet")
        if(nama.isalpha()):
            print("Masukkan Angka")


